export class Review{
  reviewerFirstName: string;
  reviewerLastName: string;
  description: string;
}
