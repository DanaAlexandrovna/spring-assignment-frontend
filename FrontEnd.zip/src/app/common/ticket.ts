export class Ticket {
  id!: number;

  // TODO we probably also need the data from the relationships with other tables
}
